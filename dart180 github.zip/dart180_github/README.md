# 🎯 180er Club – Dart Gemeinde Website

Eine einfache, lokale Website für eure Dart-Gemeinde zum Tracken aller geworfenen 180er.

## Features

- 🏆 **Rangliste** – automatisch sortiert nach Anzahl der 180er
- 📸 **180er Feed** – alle Einträge mit Foto-Beweis
- ➕ **180 Eintragen** – Spieler wählen, Datum & Foto hochladen
- 👤 **Spielerverwaltung** – Spieler hinzufügen & entfernen
- 💾 Daten werden im Browser (localStorage) gespeichert

## Deployment

### Netlify (empfohlen)
1. [netlify.com](https://netlify.com) aufrufen
2. "Add new site" → "Deploy manually"
3. Den Ordner oder die ZIP-Datei reinziehen

### GitHub Pages
1. Dieses Repository forken
2. Unter **Settings → Pages** die Branch `main` und den Ordner `/root` wählen
3. Speichern – die Seite ist unter `https://DEIN-NAME.github.io/REPO-NAME` erreichbar

### Lokal
Die `index.html` einfach im Browser öffnen – fertig.

## Technologie

- Reines HTML / CSS / JavaScript (keine Dependencies)
- localStorage für Datenpersistenz
- Kein Backend nötig
